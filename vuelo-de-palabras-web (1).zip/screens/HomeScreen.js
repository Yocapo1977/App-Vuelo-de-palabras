import React from 'react';
import { View, Text, Button } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 22 }}>Bienvenido a Vuelo de Palabras</Text>
      <Button title="Crear Poema" onPress={() => navigation.navigate('Editar')} />
    </View>
  );
}
