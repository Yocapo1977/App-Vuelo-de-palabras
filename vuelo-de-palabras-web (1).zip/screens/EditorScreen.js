import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';

export default function EditorScreen({ navigation }) {
  const [texto, setTexto] = useState("");

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <TextInput
        placeholder="Escribí tu poema aquí..."
        multiline
        style={{ height: 300, borderColor: 'gray', borderWidth: 1, marginBottom: 10 }}
        onChangeText={setTexto}
        value={texto}
      />
      <Button title="Guardar" onPress={() => navigation.navigate('Detalle', { poema: texto })} />
    </View>
  );
}
