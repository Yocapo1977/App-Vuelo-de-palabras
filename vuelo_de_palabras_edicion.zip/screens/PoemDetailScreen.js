import React from 'react';
import { View, Text, StyleSheet, Button, ScrollView, Share } from 'react-native';
import { printToFileAsync } from 'expo-print';
import * as Sharing from 'expo-sharing';

const PoemDetailScreen = ({ route, navigation }) => {
  const { poem, index } = route.params;

  const handleExportPDF = async () => {
    const html = `
      <html>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
          <h1>${poem.titulo}</h1>
          <h3>por ${poem.autor}</h3>
          <small>Fecha: ${poem.fecha}</small>
          <pre style="white-space: pre-wrap; font-size: 16px;">${poem.texto}</pre>
        </body>
      </html>
    `;
    const { uri } = await printToFileAsync({ html });
    await Sharing.shareAsync(uri);
  };

  const handleShareText = async () => {
    const mensaje = `${poem.titulo} - por ${poem.autor} (${poem.fecha})\n\n${poem.texto}`;
    await Share.share({ message: mensaje });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{poem.titulo}</Text>
      <Text style={styles.author}>por {poem.autor}</Text>
      <Text style={styles.date}>Fecha: {poem.fecha}</Text>
      <Text style={styles.text}>{poem.texto}</Text>
      <Button title="Exportar a PDF" onPress={handleExportPDF} />
      <View style={{ height: 10 }} />
      <Button title="Compartir poema" onPress={handleShareText} />
      <View style={{ height: 10 }} />
      <Button title="Editar poema" onPress={() => navigation.navigate('Editor', { poem, index })} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: 'bold' },
  author: { fontSize: 18, marginTop: 4, fontStyle: 'italic' },
  date: { fontSize: 14, marginBottom: 20, color: 'gray' },
  text: { fontSize: 18, marginBottom: 30 },
});

export default PoemDetailScreen;
