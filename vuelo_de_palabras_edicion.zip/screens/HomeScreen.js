import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Button, StyleSheet, ImageBackground } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { Picker } from '@react-native-picker/picker';
import { themes } from '../themes';

const HomeScreen = ({ navigation }) => {
  const [poems, setPoems] = useState([]);
  const [backgroundImage, setBackgroundImage] = useState(null);
  const [themeName, setThemeName] = useState('claro');
  const [currentTheme, setCurrentTheme] = useState(themes.claro);

  useEffect(() => {
    const loadData = async () => {
      const storedPoems = await AsyncStorage.getItem('poems');
      if (storedPoems) setPoems(JSON.parse(storedPoems));

      const uri = await AsyncStorage.getItem('backgroundImage');
      if (uri) setBackgroundImage(uri);

      const storedTheme = await AsyncStorage.getItem('theme');
      if (storedTheme && themes[storedTheme]) {
        setThemeName(storedTheme);
        setCurrentTheme(themes[storedTheme]);
      }
    };

    loadData();
  }, []);

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 1 });
    if (!result.canceled) {
      setBackgroundImage(result.uri);
      await AsyncStorage.setItem('backgroundImage', result.uri);
    }
  };

  const changeTheme = async (name) => {
    setThemeName(name);
    setCurrentTheme(themes[name]);
    await AsyncStorage.setItem('theme', name);
  };

  const renderItem = ({ item, index }) => (
    <TouchableOpacity onPress={() => navigation.navigate('PoemDetail', { index, poem: item })} style={[styles.item, { backgroundColor: currentTheme.cardColor }]}>
      <Text style={{ color: currentTheme.textColor, fontWeight: 'bold' }}>{item.titulo}</Text>
      <Text style={{ color: currentTheme.textColor }}>por {item.autor}</Text>
    </TouchableOpacity>
  );

  return (
    <ImageBackground source={backgroundImage ? { uri: backgroundImage } : null} style={styles.background} resizeMode="cover">
      <View style={[styles.container, { backgroundColor: currentTheme.backgroundColor }]}>
        <Button title="Escribir un nuevo poema" onPress={() => navigation.navigate('Editor')} />
        <Button title="Cambiar fondo" onPress={pickImage} />
        <Text style={{ color: currentTheme.textColor, marginTop: 10 }}>Tema visual:</Text>
        <Picker selectedValue={themeName} onValueChange={changeTheme} style={{ color: currentTheme.textColor }}>
          <Picker.Item label="Claro" value="claro" />
          <Picker.Item label="Oscuro" value="oscuro" />
          <Picker.Item label="Vintage" value="vintage" />
          <Picker.Item label="Marino" value="marino" />
        </Picker>
        <FlatList data={poems} renderItem={renderItem} keyExtractor={(_, index) => index.toString()} style={styles.list} />
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: { flex: 1 },
  container: { flex: 1, padding: 20 },
  list: { marginTop: 20 },
  item: { padding: 15, borderBottomWidth: 1, borderBottomColor: '#ccc', borderRadius: 5, marginBottom: 10 },
});

export default HomeScreen;
