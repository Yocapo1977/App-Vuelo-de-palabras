import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, StyleSheet, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const EditorScreen = ({ navigation, route }) => {
  const { poem, index } = route.params || {};
  const [titulo, setTitulo] = useState('');
  const [autor, setAutor] = useState('');
  const [texto, setTexto] = useState('');

  useEffect(() => {
    if (poem) {
      setTitulo(poem.titulo);
      setAutor(poem.autor);
      setTexto(poem.texto);
    }
  }, []);

  const guardarPoema = async () => {
    if (!titulo || !autor || !texto) {
      Alert.alert('Faltan datos', 'Por favor completá todos los campos.');
      return;
    }

    const nuevoPoema = {
      titulo,
      autor,
      texto,
      fecha: poem?.fecha || new Date().toISOString().split('T')[0],
    };

    try {
      const storedPoems = await AsyncStorage.getItem('poems');
      const poems = storedPoems ? JSON.parse(storedPoems) : [];

      if (typeof index === 'number') {
        poems[index] = nuevoPoema;
      } else {
        poems.push(nuevoPoema);
      }

      await AsyncStorage.setItem('poems', JSON.stringify(poems));
      navigation.goBack();
    } catch (error) {
      console.error('Error al guardar el poema:', error);
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Título" value={titulo} onChangeText={setTitulo} style={styles.input} />
      <TextInput placeholder="Autor" value={autor} onChangeText={setAutor} style={styles.input} />
      <TextInput placeholder="Escribí tu poema..." value={texto} onChangeText={setTexto} style={[styles.input, { height: 150 }]} multiline />
      <Button title="Guardar poema" onPress={guardarPoema} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, gap: 15 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 12, borderRadius: 5 },
});

export default EditorScreen;
